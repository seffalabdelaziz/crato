<?php
/**
*
*	(p) package: Lumise pdf.php
*	(c) author:	King-Theme
*	(i) website: https://www.lumise.com
*
*/	

global $lumise;

echo 434334;